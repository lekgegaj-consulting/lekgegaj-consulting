# MSG-130 [TOOL]
Archived: 2026-02-26T06:10:43.119895+00:00

---

{"file_path": "postcss.config.js", "success": true, "file_type": "text", "extraction_method": "cat", "size_bytes": 162, "content_length": 161, "truncated": false, "content": "import type { Config } from 'postcss-load-config'\n\nconst config: Config = {\n  plugins: {\n    tailwindcss: {},\n    autoprefixer: {},\n  },\n}\n\nexport default config"}